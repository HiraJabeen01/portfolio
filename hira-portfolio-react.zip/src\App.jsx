import profileImage from '../assets/hira-profile.png';

const services = [
  {
    title: 'Full-Stack Web Development',
    text: 'Modern SaaS apps, business portals, APIs, and custom systems built with scalable architecture.',
    items: ['SaaS Applications', 'MVP Development', 'API Development', 'Database Design'],
  },
  {
    title: 'DevOps & Cloud Engineering',
    text: 'Reliable delivery pipelines and cloud infrastructure that improve release speed and operational confidence.',
    items: ['CI/CD Pipelines', 'Azure Infrastructure', 'Docker & Kubernetes', 'Terraform'],
  },
  {
    title: 'Application Modernization',
    text: 'Legacy systems and deployment processes transformed into cloud-ready, maintainable platforms.',
    items: ['Cloud Migration', 'Performance Optimization', 'Security Improvements', 'Release Automation'],
  },
];

const projects = [
  {
    eyebrow: 'Featured Project',
    title: 'FirstFrame Enterprise SaaS Platform',
    text: 'Led engineering delivery for a multi-tenant SaaS platform with automated CI/CD, cloud-native infrastructure, and Microsoft Teams integration.',
    outcomes: ['MVP delivered in under 10 months', '5 pilot customers onboarded', '40% reduction in cloud infrastructure costs'],
    stack: 'Azure / Docker / Kubernetes / Terraform / GitHub Actions',
  },
  {
    eyebrow: 'Corporate Website',
    title: 'Microtechx Digital Presence',
    text: 'Designed and developed a responsive enterprise website for Cloud, AI, Security Modernization, and SAP consulting services.',
    outcomes: ['Professional enterprise brand presence', 'Improved service discoverability', 'Clear service-focused user journeys'],
    stack: 'React / TypeScript / Responsive Design',
  },
  {
    eyebrow: 'Architecture Lab',
    title: 'Distributed Voting Platform',
    text: 'Built a distributed microservices voting system to demonstrate containerized deployment, orchestration, and resilient service communication.',
    outcomes: ['Highly available architecture', 'Production-ready infrastructure patterns', 'Scalable deployment model'],
    stack: 'Python / Node.js / .NET / Redis / PostgreSQL / Kubernetes',
  },
];

const technologies = ['Azure', 'Docker', 'K8s', 'Terraform', 'React', 'Node', 'ASP.NET', 'Python', 'Postgres', 'MongoDB'];

function App() {
  return (
    <div className="site-shell">
      <header className="topbar">
        <a className="brand" href="#home" aria-label="Hira Jabeen home">HJ</a>
        <nav aria-label="Primary navigation">
          <a href="#services">Services</a>
          <a href="#work">Work</a>
          <a href="#about">About</a>
          <a href="#contact">Contact</a>
        </nav>
      </header>

      <main>
        <section className="hero section" id="home">
          <div className="hero-copy">
            <p className="eyebrow">Full-Stack Development & DevOps Solutions</p>
            <h1>Build. Deploy. Scale.</h1>
            <p className="hero-lede">
              I help SaaS startups and growing technology companies transform ideas into production-ready software through modern web development, cloud infrastructure, CI/CD automation, and scalable architecture.
            </p>
            <div className="hero-actions">
              <a className="button primary" href="mailto:hira.jabeen@microtechx.com">Book a Discovery Call</a>
              <a className="button ghost" href="#work">View Case Studies</a>
            </div>
            <div className="capabilities" aria-label="Core capabilities">
              <span>Full-Stack Development</span>
              <span>Cloud & DevOps Engineering</span>
              <span>CI/CD Automation</span>
              <span>Azure Infrastructure</span>
              <span>Docker & Kubernetes</span>
            </div>
          </div>
          <div className="hero-visual" aria-label="Portrait of Hira Jabeen">
            <div className="portrait-orbit"></div>
            <img src={profileImage} alt="Hira Jabeen" />
            <div className="floating-card top">
              <strong>Cloud & AI</strong>
              <span>Engineering Lead</span>
            </div>
            <div className="floating-card bottom">
              <strong>100%</strong>
              <span>Automated delivery focus</span>
            </div>
          </div>
        </section>

        <section className="section services" id="services">
          <div className="section-heading">
            <p className="eyebrow">Services</p>
            <h2>Production-minded engineering for teams ready to move faster.</h2>
          </div>
          <div className="service-grid">
            {services.map((service) => (
              <article className="service-card" key={service.title}>
                <div className="card-icon" aria-hidden="true">{service.title.charAt(0)}</div>
                <h3>{service.title}</h3>
                <p>{service.text}</p>
                <ul>
                  {service.items.map((item) => <li key={item}>{item}</li>)}
                </ul>
              </article>
            ))}
          </div>
        </section>

        <section className="section work" id="work">
          <div className="project featured">
            <div>
              <p className="eyebrow">{projects[0].eyebrow}</p>
              <h2>{projects[0].title}</h2>
              <p>{projects[0].text}</p>
              <div className="outcomes">
                {projects[0].outcomes.map((outcome) => <span key={outcome}>{outcome}</span>)}
              </div>
              <p className="stack">{projects[0].stack}</p>
            </div>
            <div className="project-preview" aria-hidden="true">
              <div className="preview-window">
                <span></span>
                <span></span>
                <span></span>
              </div>
              <div className="preview-lines">
                <i></i>
                <i></i>
                <i></i>
              </div>
              <div className="preview-panel"></div>
            </div>
          </div>

          <div className="project-grid">
            {projects.slice(1).map((project) => (
              <article className="project-card" key={project.title}>
                <p className="eyebrow">{project.eyebrow}</p>
                <h3>{project.title}</h3>
                <p>{project.text}</p>
                <div className="mini-outcomes">
                  {project.outcomes.map((outcome) => <span key={outcome}>{outcome}</span>)}
                </div>
                <p className="stack">{project.stack}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="section about" id="about">
          <div>
            <p className="eyebrow">About Me</p>
            <h2>I’m Hira Jabeen, a Full-Stack Developer and DevOps Engineer.</h2>
            <p>
              My experience spans software development, cloud engineering, CI/CD automation, infrastructure as code, and modern DevOps practices. I work with startups and technology companies to accelerate product delivery, improve deployment reliability, and create systems designed to scale.
            </p>
            <p>
              My approach focuses on measurable business outcomes: faster releases, improved reliability, reduced operational overhead, and scalable technology foundations that support long-term growth.
            </p>
          </div>
          <div className="tech-orbit" aria-label="Core technologies">
            <div className="core-mark">HJ</div>
            {technologies.map((tech, index) => (
              <span key={tech} style={{ '--i': index }}>{tech}</span>
            ))}
          </div>
        </section>

        <section className="section contact" id="contact">
          <p className="eyebrow">Contact</p>
          <h2>Let’s build something scalable.</h2>
          <p>
            Whether you’re launching a SaaS product, modernizing infrastructure, or improving deployment reliability, I’d be happy to discuss your goals.
          </p>
          <div className="contact-actions">
            <a className="button primary" href="mailto:hira.jabeen@microtechx.com">hira.jabeen@microtechx.com</a>
            <a className="button ghost" href="https://linkedin.com/in/hira-jabeen-cloud-engineer" target="_blank" rel="noreferrer">LinkedIn</a>
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;
